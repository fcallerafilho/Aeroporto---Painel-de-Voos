#ifndef DELAY_H
#define	DELAY_H

void tempo(unsigned char x);

#endif	

